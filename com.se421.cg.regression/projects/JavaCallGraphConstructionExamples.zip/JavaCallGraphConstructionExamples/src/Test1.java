
public class Test1 {

	public void test1() {
		// this is just here as a sanity check
	}
	
}
